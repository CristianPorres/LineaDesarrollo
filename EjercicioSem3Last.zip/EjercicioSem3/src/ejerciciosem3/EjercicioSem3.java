/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciosem3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

/**
 *
 * @author Estudiantes
 */
public class EjercicioSem3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        File archivo = new File("/home/cporres/Escritorio/bd_sin_descripcion.csv");
        FileReader reader = new FileReader(archivo);
        BufferedReader br = new BufferedReader(reader);
        String linea;

        int cont = 0;
        int numeroMenor = 999999999;
        int numeroMayor = 0;
        int banderaIndicador = 0;
        int indicador = 1;
        int contIndicador = 0;
        int key = 0;
        double suma = 0;

        String numeroItem = "";
        String numeroItemMayor = "";
        String[] indicadores = new String[25];
        String[] listaIndicador;

        HashMap<String, Integer> lista = new HashMap<String, Integer>();
        SortedMap map = new TreeMap(java.util.Collections.reverseOrder());
        while ((linea = br.readLine()) != null) {
            //System.out.println(linea);

            String[] datos = linea.split(",");
            if (cont == 0) {
                cont++;
                continue;

            } else {

                if (Integer.valueOf(datos[1]) < numeroMenor) {
                    numeroMenor = Integer.valueOf(datos[1]);
                    numeroItem = datos[0];
                }

                if (Integer.valueOf(datos[1]) > numeroMayor) {

                    numeroMayor = Integer.valueOf(datos[1]);
                    numeroItemMayor = datos[0];

                    lista.put(numeroItemMayor, numeroMayor);

                }

                String indi = datos[0].toString();
                listaIndicador = indi.split("\\.");

                banderaIndicador = Integer.parseInt(listaIndicador[0]);

                if (indicador == banderaIndicador) {
                    contIndicador = contIndicador + 1;
                } else {

                    indicadores[key] = indicador + " = " + contIndicador;
                    key = key + 1;

                    indicador = Integer.parseInt(listaIndicador[0]);
                    contIndicador = 0;
                    contIndicador = contIndicador + 1;
                }
            }

            suma = suma + Double.valueOf(datos[1]);
            cont++;
        }

        Map<String, Integer> sortedDescMap = sortByDesc(lista);

        int contMayor = 0;
        System.out.println("Los items de mayor costo son:");
        for (Map.Entry caracter : sortedDescMap.entrySet()) {

            System.out.println(caracter.getKey());
            contMayor++;

            if (contMayor == 5) {
                break;
            }
        }

        indicadores[key] = indicador + " = " + contIndicador;
        System.out.println("El item más barato es " + numeroItem);
        System.out.println("El item de mayor costo es: " + numeroItemMayor);
        System.out.println("La cantidad de registros es: " + (cont - 1));
        System.out.println("La suma  de los indicadores: " + suma);
        System.out.println("El promedio de los indicadores: " + (suma / (cont - 1)));
        for (int i = 0; i < indicadores.length; i++) {
            System.out.println(indicadores[i]);
        }
        getWord();
        

    }

    private static Map sortByDesc(Map unsortMap) {
        List list = new LinkedList(unsortMap.entrySet());
        //Para ordenar descendentemente
        Collections.sort(list, new Comparator() {
            public int compare(Object o1, Object o2) {
                return ((Comparable) ((Map.Entry) (o2)).getValue())
                        .compareTo(((Map.Entry) (o1)).getValue());
            }
        });
        Map<String, Integer> sortedMap = new LinkedHashMap<String, Integer>();
        for (Iterator it = list.iterator(); it.hasNext();) {
            Map.Entry<String, Integer> entry = (Map.Entry< String, Integer>) it.next();
            sortedMap.put(entry.getKey(), entry.getValue());
        }
        return sortedMap;
    }
    
    private static void getWord() throws FileNotFoundException, IOException {
        File archivo = new File("/home/cporres/Escritorio/BD.csv");
        FileReader reader = new FileReader(archivo);
        BufferedReader br = new BufferedReader(reader);
        String linea;
        String i;
        HashMap<String, Integer> lista = new HashMap<String, Integer>();
        while ((linea = br.readLine()) != null) {
            String[] datos = linea.split(",");
            String[] desc = datos[1].split(" ");
            i = desc[0].replace("\"", "").replace(",", "").trim();
            if (lista.containsKey(i)) {
                int flag = lista.get(i);
                lista.put(i, flag+1);
            } else {
                lista.put(i, 1);
            }
        }
        sortByDesc(lista);
        Map.Entry<String, Integer> maxEntry = null;

        for (Map.Entry<String, Integer> entry : lista.entrySet()) {

            if (maxEntry == null
                    || entry.getValue().compareTo(maxEntry.getValue()) > 0) {
                maxEntry = entry;
            }
        }
        System.out.println("La palabra mas comun al inicio de las descripciones es " + maxEntry + " veces");
    }

}

